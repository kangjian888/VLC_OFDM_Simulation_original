
clear all; clc;

a = 15;
b = 15;
c = 15;
d = 150;


if a<30||b<30||c<30||d<30
    p = 100;
else
    p=0;
end

p