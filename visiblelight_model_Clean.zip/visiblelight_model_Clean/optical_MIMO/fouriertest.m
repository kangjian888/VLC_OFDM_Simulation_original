
clear all;
clc;

syms t w f ratio
x = t.*exp(-2.*t).*heaviside(t);
P = fourier(x,w)
% w = -20:.1:20;
% X = subs(X,w);
% plot(w,abs(X));
% legend('magnitude')
