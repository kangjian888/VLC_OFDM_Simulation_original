function [X,Y] = createmeshgrid(radius)

[X,Y] = meshgrid(-radius:.1:radius);