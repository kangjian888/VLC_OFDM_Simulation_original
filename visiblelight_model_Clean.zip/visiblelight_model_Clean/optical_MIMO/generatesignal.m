

clear all; clc;
t = -5:.001:10;
s = rectpuls(t,2);
plot(t,s)
ylim([-.3 1.3])