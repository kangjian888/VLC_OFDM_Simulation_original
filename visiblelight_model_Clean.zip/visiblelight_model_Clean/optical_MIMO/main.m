
clear all; clc;

[Xpoint,Ypoint]=rect('start');