function varargout = illuminanceGUI(varargin)

% ILLUMINANCEGUI M-file for illuminanceGUI.fig
%      ILLUMINANCEGUI, by itself, creates a new ILLUMINANCEGUI or raises the existing
%      singleton*.
%
%      H = ILLUMINANCEGUI returns the handle to a new ILLUMINANCEGUI or the handle to
%      the existing singleton*.
%
%      ILLUMINANCEGUI('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in ILLUMINANCEGUI.M with the given input arguments.
%
%      ILLUMINANCEGUI('Property','Value',...) creates a new ILLUMINANCEGUI or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before illuminanceGUI_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to illuminanceGUI_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help illuminanceGUI

% Last Modified by GUIDE v2.5 06-Sep-2011 15:12:35

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @illuminanceGUI_OpeningFcn, ...
                   'gui_OutputFcn',  @illuminanceGUI_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before illuminanceGUI is made visible.
function illuminanceGUI_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to illuminanceGUI (see VARARGIN)

% Choose default command line output for illuminanceGUI
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes illuminanceGUI wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = illuminanceGUI_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on slider movement.
function slider1_Callback(hObject, eventdata, handles)
% hObject    handle to slider1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global r;
global viewangle;
cla
r=get(hObject,'value');
set(handles.edit1,'string',r)

%viewangle=get(handles.slider2,'value');
%set(handles.edit3,'string',viewangle)
axes(handles.axes1)

p = 0;
%RADIUS = r;
RADIUS = tand(r)*1.5;

circle([p,p],RADIUS,150,'.');
hold on
circle([p,p],(2/3)*RADIUS,100,'.');
hold on
circle([p,p],(1/3)*RADIUS,60,'.');
hold on
circle([p,p],(0.2/3)*RADIUS,30,'.');

guidata(hObject, handles);
hold off

axes(handles.axes2)
%viewing angle of LED = viewangle

%electron charge (C)
q = 1.60E-19;
%angle of irradiance (half phi)
phi = (r*pi)/180;

%angle of incidence
psi = (15*pi)/180;
%power emitted by LED (mW)
PLED = 30;
%detector area, ARX (or photodiode active area) (cm^2)
ARX = 50/100;
%FOV (field of view) of detector, psi_c
psi_c = (40*pi)/180;
%distance between tx and rx (m)
hd = 1.5;
%height of room
H = 2.0;

%order of Lambertian emission
m = real(-log(2)/log(cos(phi)));
%Lambertian radiant intensity (or transmitter radiant intensity)
Ro = real(((m+1)/(2*pi))*cos(phi)^m);
%transmitted power, PTX
PTX = PLED*Ro;
%LOS (line of sight) propagation path channel transfer function - HLOS
if (psi>=0) && (psi<=psi_c)
    HLOS = (ARX/hd^2)*Ro*cos(psi);
elseif (psi>psi_c)
    HLOS = 0.0;
elseif (r>viewangle)
    HLOS = 0.0;
else
    HLOS = 0.0;
end;

%number of LEDs per led array - NoLEDs
NoLEDs = 30;
%total power of i LEDs in the directed path - PRXLOS
PRXLOS = NoLEDs*PTX*HLOS;


%photodiode responsitivity
response = 0.4;
%noise power of ambient light
pn = 5840E-6*sqrt(5);
%data rate 
Rb = 115200;
%noise bandwidth factor
I2 = 0.562;
Bn = Rb*I2;
%amplifier bandwidth
Ba = 250E5;
%amplifier noise current
iamplifier = 5E-12*Ba;

%total surface area of room - Aroom
Aroom = 5*5*2 + 5*H*2 + 5*H*2;
Floor_area = 5*5;
Wall1_area = 5*H*2;
Wall2_area = 5*H*2;
Ceiling_area = 5*5;
%average reflectivity - rho
rho = (1/Aroom)*(Floor_area*0.15 + ...
    Wall1_area*0.7  + ...
    Wall2_area*0.7  + ...
    Ceiling_area*0.8);
%the first diffused reflection of a wide-beam optical source emits an
%intensity 'Iprime' over the whole room surface 'Aroom'.
I = rho*PRXLOS/Aroom;
Iprime = I/(1-rho);
%received diffused power 'pdiff' with the photodiode's receiving area ARX
pdiff = ARX*Iprime;
%At the receiver, light passes through the optical filter 'Tf' and 
%concentrator 'g'. 
%Tf is the transmission coefficient of the optical filter.
Tf = 1.0;
%g is the concentrator index. I used a x6 lens for the concentrator, so
g = 6;
%so the received power prx is
prx = (PRXLOS+pdiff)*Tf*g;
%In fact, there is also the refractive index of the lens/glass/plastic 
%covering the photodiode to consider (whose value is about 1.0-1.5); 
%however, it is usually ignored.
%shot noise variance - omegashot
omegashot = 2*q*response*(prx+pn)*Bn;
%amplifier noise variance - omegaamplifier
omegaamplifier = iamplifier^2*Ba;
%total noise variance - omegatotal
omegatotal = omegashot+omegaamplifier;
%signal-to-noise ratio SNR
SNR = (response*prx)^2/(omegatotal);
%convert SNR unit to dB
SNRdb = 20*log10(SNR);

%get radius from height H (between the transmitter and receiver) at
%irradiance angle phi
radius = H/tan(pi-pi/2-phi);
%set grid using radius 
[X,Y] = meshgrid(-radius:.1:radius); 
%Geometry - get hypotenuse R
R = sqrt((X).^2 + (Y).^2)./cos(pi-pi/2-phi);

%distance between each led array
dist_apart = 1.5;

%translate SNR array to the graph function fx = (sin x)/x.
%Refer to http://press.princeton.edu/books/maor/chapter_10.pdf for 
%more info on sin graphs.
Z = SNRdb*sin(R)./R;
mesh(X+dist_apart,Y,Z,'EdgeColor','black')
xlabel('Length of room [m]')
ylabel('Width of room [m]')
zlabel('SNR [db]')
%axis([-2.5 2.5 -2.5 2.5 0 1])
hold on

mesh(X,Y,Z,'EdgeColor','black')
xlabel('Length of room [m]')
ylabel('Width of room [m]')
zlabel('SNR [db]')
%axis([-2.5 2.5 -2.5 2.5 0 1])
hold on

mesh(X,Y+dist_apart,Z,'EdgeColor','black')
xlabel('Length of room [m]')
ylabel('Width of room [m]')
zlabel('SNR [db]')
%axis([-2.5 2.5 -2.5 2.5 0 1])
hold on

mesh(X+dist_apart,Y+dist_apart,Z,'EdgeColor','black')
xlabel('Length of room [m]')
ylabel('Width of room [m]')
zlabel('SNR [db]')
%axis([-2.5 2.5 -2.5 2.5 0 1])
hold on

title('Communication using White-LED: SNR 3D Plot for Room Illumination')
hold off
guidata(hObject, handles);
% returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider


% --- Executes during object creation, after setting all properties.
function slider1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to slider1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end
set(hObject,'value',0);
set(hObject,'max',90);
set(hObject,'min',0);



function edit1_Callback(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
n=str2double(get(hObject,'String'));
radians = n*pi/180;
%set(handles.slider1,'value',radians)
% Hints: get(hObject,'String') returns contents of edit1 as text
%        str2double(get(hObject,'String')) returns contents of edit1 as a double
guidata(hObject, handles);


% --- Executes during object creation, after setting all properties.
function edit1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
set(hObject,'string',0);


% --- Executes on slider movement.
function slider2_Callback(hObject, eventdata, handles)
% hObject    handle to slider2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

global viewangle;

%r=get(handles.slider1,'value')
%set(handles.edit1,'string',r)


viewangle=get(hObject,'value');
set(handles.edit3,'string',viewangle)



% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider


% --- Executes during object creation, after setting all properties.
function slider2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to slider2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end
set(hObject,'value',0);
set(hObject,'max',90);
set(hObject,'min',0);



function edit3_Callback(hObject, eventdata, handles)
% hObject    handle to edit3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
n1=str2double(get(hObject,'String'));
radians1 = n1*pi/180;
%set(handles.slider2,'value',radians1)
% Hints: get(hObject,'String') returns contents of edit1 as text
%        str2double(get(hObject,'String')) returns contents of edit1 as a double
guidata(hObject, handles);
% Hints: get(hObject,'String') returns contents of edit3 as text
%        str2double(get(hObject,'String')) returns contents of edit3 as a double


% --- Executes during object creation, after setting all properties.
function edit3_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
set(hObject,'string',0);


% --- Executes on slider movement.
function slider3_Callback(hObject, eventdata, handles)
% hObject    handle to slider3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider


% --- Executes during object creation, after setting all properties.
function slider3_CreateFcn(hObject, eventdata, handles)
% hObject    handle to slider3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end



function edit4_Callback(hObject, eventdata, handles)
% hObject    handle to edit4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit4 as text
%        str2double(get(hObject,'String')) returns contents of edit4 as a double


% --- Executes during object creation, after setting all properties.
function edit4_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
