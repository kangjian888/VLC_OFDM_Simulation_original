

clear all; clc;

irradiance = 10;
incidence = 10;
LED_VA = 15;
PD_FOV = 20;

[X,Y,Z] = illuminance(irradiance,incidence,LED_VA,PD_FOV);

mesh(X,Y,Z,'EdgeColor','black')
xlabel('Length of room [m]')
ylabel('Width of room [m]')
zlabel('SNR [db]')
% %axis([-2.5 2.5 -2.5 2.5 0 1])