clear all;
clc;

p = 25;
RADIUS = 15;


circle([p,p],RADIUS,150,'.');
hold on
circle([p,p],(2/3)*RADIUS,100,'.');
hold on
circle([p,p],(1/3)*RADIUS,60,'.');
hold on
circle([p,p],(0.2/3)*RADIUS,40,'.');