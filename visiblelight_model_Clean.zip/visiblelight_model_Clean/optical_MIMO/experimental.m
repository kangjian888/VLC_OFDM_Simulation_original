clear all; clc;


radii = .2;

xbar = [-3/3*0.2 -2/3*0.2 -1/3*0.2 0 1/3*0.2 2/3*0.2 3/3*0.2];
intensity = [7.6 16 21.8 22.8 21.8 16 7.6];

% figure(1)
% plot(xbar,intensity)
% xlabel('Cone Diameter (m)')
% ylabel('Luminous Intensity (cd)')


xbar = [-3/3*0.2 -2/3*0.2 -1/3*0.2 0 1/3*0.2 2/3*0.2 3/3*0.2];
illuminance = [73.2 163.5 204.1 209.7 204.1 163.5 73.2];

% figure(2)
% plot(xbar,illuminance)
% xlabel('Cone Diameter (m)')
% ylabel('Illuminance (lux)')


xbar = [-3/3*0.2 -2/3*0.2 -1/3*0.2 -0.2*0.2 0 0.2*0.2 1/3*0.2 2/3*0.2 3/3*0.2]
xbaro = [3/3*0.2 2/3*0.2 1/3*0.2 0.2*0.2 0];
sphere_rad = sqrt(xbar.^2 + 1.5.^2);
ray_dissect = 0:1.4935/4:1.4935;
% [xis,yis] = meshgrid(xbar,xbar);
% ZR = sqrt(1.5^2 + yis.^2);
% df = sin(ZR)/ZR;
ampere = [4.96 9.9 16.3 21.3 24.4 21.3 16.3 9.9 4.96];
power = ampere*(10^-6)/0.45;
amp = [24.4 21.3 16.3 9.9 4.96];
gap = linspace(0.0,1.4935,5);
sphere_radius = linspace(-1.4935,1.4935,9);
powerx = gap*4.96/1.4935;
power_per_sq_m = power./(4*pi*sphere_radius.^2);
%xx = meshgrid(power);

plot(sphere_radius,power)

height_chop = linspace(0,1.5,5);
a1 = [4.96 9.9 16.3 19.6 24.4];
dis = [0.001 0.0667 0.0667*2 0.0667*2+0.0267 0.0667*2+0.0267+0.04];

ratio1 = (fliplr(a1)-4.96)./dis.*height_chop+fliplr(a1);

cone_slope = a1/cosd(7.5);
xy = [-3/3*0.2 -2/3*0.2 -1/3*0.2 -0.2*0.2 0];


%plot(xy,cone_slope)

    
  uamp=[4.96 4.96 4.96 4.96 4.96 4.96 4.96 4.96 4.96;...
        4.96 12.2 12.2 12.2 12.2 12.2 12.2 12.2 4.96;...
        4.96 12.2  18 18 18 18 18 12.2  4.96;...
        4.96 12.2  18 20.34 20.34 20.34 18 12.2  4.96;...
        4.96 12.2  18 20.34 24.4 20.34 18 12.2  4.96;...
        4.96 12.2  18 20.34 20.34 20.34 18 12.2  4.96;...
        4.96 12.2  18 18 18 18 18 12.2  4.96;...
        4.96 12.2  12.2  12.2  12.2  12.2  12.2  12.2  4.96;...
        4.96 4.96 4.96 4.96 4.96 4.96 4.96 4.96 4.96];
        
[xx,yy] = meshgrid(xbar);


sds = [24.4 20.34 18 12.2 4.96];
sdc = [0 0.2*0.2 1/3*0.2 2/3*0.2 3/3*0.2];

plot(sdc,sds)

%[s,l] = meshgrid(dd);
%meshc(xx,yy,uamp)
%figure(3)
%plot(xbaro,powerx)
% xlabel('Cone Diameter (m)')
% ylabel('Received Power (dB20)')
% figure(5)
% mesh(xis,yis,df)
