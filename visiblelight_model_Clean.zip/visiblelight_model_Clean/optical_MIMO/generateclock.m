

clear all; clc;

[s,t] = gensig('square',0.000000003,0.000000003*10,0.00000000001);
plot(t,s)
ylim([0 2])
xlim([0 8E-8])
