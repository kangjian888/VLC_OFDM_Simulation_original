

x = [-3/3*0.2 -2/3*0.2 -1/3*0.2 -0.2*0.2 0 0.2*0.2 0.2*1/3 0.2*2/3 0.2*3/3];
y = [4.96 9.9 16.3 21.3 24.4 21.3 16.3 9.9 4.96];

p = polyfit(x,y,3);

x2 = -.2:.01:.2;
y2 = polyval(p,x2);
plot(x,y,'o',x2,y2)

% [estimates, model] = fitcurvedemo(x,y);
% 
% plot(x, y, '*')
% hold on
% [sse, FittedCurve] = model(estimates);
% plot(x, FittedCurve, 'r')
%  
% xlabel('xdata')
% ylabel('f(estimates,xdata)')
% title(['Fitting to function ', func2str(model)]);
% legend('data', ['fit using ', func2str(model)]);
% hold off