
clear all; clc;
lengthx = 1:10;

[x,y] = meshgrid(lengthx)