

clear all; clc;



[X1,X2] = meshgrid(linspace(-2,2,25)',linspace(-2,2,25)');
X = [X1(:) X2(:)];
C = [4 1; 1 4]; 
df = 6;
p = mvtpdf(X,C,df);
surf(X1,X2,reshape(p,25,25))